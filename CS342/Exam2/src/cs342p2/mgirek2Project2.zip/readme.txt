To build the program :
	- type ‘make’ into any IDE of your choice
To run executable:
	- type ‘java ExamTester’